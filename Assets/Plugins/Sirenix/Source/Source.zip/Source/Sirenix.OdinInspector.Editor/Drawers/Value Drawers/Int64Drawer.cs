//-----------------------------------------------------------------------
// <copyright file="Int64Drawer.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinInspector.Editor.Drawers
{
    using Sirenix.Utilities.Editor;
    using UnityEngine;

    /// <summary>
    /// Long property drawer.
    /// </summary>
    public sealed class Int64Drawer : OdinValueDrawer<long>
    {
        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            if (GeneralDrawerConfig.Instance.EnableSmartNumberFields)
            {
                this.ValueEntry.SmartValue = SirenixEditorFields.SmartLongField(this.Property.ToFieldExpressionContext(), label, this.ValueEntry.SmartValue);
            }
            else
            {
                this.ValueEntry.SmartValue = SirenixEditorFields.LongField(label, this.ValueEntry.SmartValue);
            }
        }
    }
}
#endif