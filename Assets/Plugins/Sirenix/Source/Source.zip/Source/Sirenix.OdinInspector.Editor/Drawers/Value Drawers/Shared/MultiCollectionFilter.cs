//-----------------------------------------------------------------------
// <copyright file="MultiCollectionFilter.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinInspector.Editor.Drawers
{
	using System;
	using System.Collections.Generic;
	using Sirenix.Utilities;
	using Sirenix.Utilities.Editor;
	using UnityEditor;
	using UnityEngine;

	public class MultiCollectionFilter<TResolver> where TResolver : ICollectionResolver
	{
		private const int INVALID_COUNT = -1;

		public bool IsFiltered => this.IsUsed && this.FilteredChildren.Count > 0;
		
		public readonly bool IsUsed;
		
		public PropertySearchFilter Filter;
		
		internal string            ControlName;
		internal InspectorProperty Property;
		
		internal PropertyChildren        Children;
		internal List<InspectorProperty> FilteredChildren;
		internal int                     LastChildrenCount;

		internal readonly Action ScheduledUpdateAction;
		
		public MultiCollectionFilter(InspectorProperty property, TResolver resolver) 
		{
			this.ControlName = $"PropertyTreeSearchField_{Guid.NewGuid()}";
			this.Property    = property;
			this.Children    = property.Children;

			this.LastChildrenCount = this.Children.Count;

			var searchable = property.GetAttribute<SearchableAttribute>();

			if (searchable is null) 
			{
				this.IsUsed = false;
				return;
			}

			this.Filter = new PropertySearchFilter(null, searchable);
			this.FilteredChildren = new List<InspectorProperty>(this.Children.Count);
			
			resolver.OnAfterChange += change => 
			{
				this.Property.Children.Update();
				this.Update();
			};

			this.ScheduledUpdateAction = () => 
			{
				this.Update();
				GUIHelper.RequestRepaint();
			};

			this.IsUsed = true;
		}

		public InspectorProperty this[int index] => this.IsFiltered ? this.FilteredChildren[index] : this.Children[index];

		public int GetCount() 
		{
			if (this.Children.Count != this.LastChildrenCount) 
			{
				this.Update();
				this.LastChildrenCount = this.Children.Count;
			}

			return this.IsFiltered ? this.FilteredChildren.Count : this.Children.Count;
		}

		public void Draw() 
		{
			if (!this.IsUsed)
			{
				return;
			}

			Rect rect = EditorGUILayout.GetControlRect(false).AddYMin(2);

			if (UnityVersion.IsVersionOrGreater(2019, 3)) 
			{
				rect = rect.AddY(-2);
			}

			this.Draw(rect);
		}

		public void Draw(Rect rect) 
		{
			string searchTerm = SirenixEditorGUI.SearchField(rect, this.Filter.SearchTerm, false, this.ControlName);

			if (searchTerm == this.Filter.SearchTerm)
			{
				return;
			}

			if (!string.IsNullOrEmpty(searchTerm)) 
			{
				this.Property.State.Expanded = true;
			}

			this.Filter.SearchTerm = searchTerm;

			this.ScheduleUpdate();
		}

		public void Update() 
		{
			if (!this.IsUsed) 
			{
				return;
			}

			this.FilteredChildren.Clear();
				
			if (string.IsNullOrEmpty(this.Filter.SearchTerm))
			{
				return;
			}
			
			for (var i = 0; i < this.Children.Count; i++) 
			{
				InspectorProperty parentProperty = this.Children[i];

				for (var j = 0; j < parentProperty.Children.Count; j++) 
				{
					InspectorProperty property = parentProperty.Children[j];

					if (this.Filter.IsMatch(property, this.Filter.SearchTerm))
					{
						this.FilteredChildren.Add(parentProperty);
						break;
					}

					if (!this.Filter.Recursive) 
					{
						continue;
					}

					var foundMatch = false;
					
					foreach (InspectorProperty recursiveProperty in property.Children.Recurse()) 
					{
						if (!this.Filter.IsMatch(recursiveProperty, this.Filter.SearchTerm)) 
						{
							continue;
						}

						this.FilteredChildren.Add(parentProperty);
						foundMatch = true;
						break;
					}

					if (foundMatch) 
					{
						break;
					}
				}
			}
		}

		public void ScheduleUpdate() => Property.Tree.DelayActionUntilRepaint(this.ScheduledUpdateAction);
	}
}
#endif